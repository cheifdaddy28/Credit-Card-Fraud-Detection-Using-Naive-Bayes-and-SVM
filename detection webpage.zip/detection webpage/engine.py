# import libraries
import joblib
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

pipe = joblib.load('model/pipe.pkl')
model = joblib.load('model/svm.pkl')


def makePcaPred(X):

    # Fit the PCA to the data and transform the data using the PCA object
    X_pca = pipe.transform(X)
    return model.predict(X_pca)
