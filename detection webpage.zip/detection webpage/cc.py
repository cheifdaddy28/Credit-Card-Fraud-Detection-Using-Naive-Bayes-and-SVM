import streamlit as st
import pandas as pd
import numpy as np

#importing functions from engine module
from engine import makePcaPred

st.title("Credit Card Detector App")

# Define the input fields for the credit card information
type = st.selectbox(
    'Type',
    ['CASH_IN', 'CASH_OUT', 'DEBIT', 'PAYMENT', 'TRANSFER'])
amount = st.text_input("Amount")
oldbalanceOrig = st.text_input("Old balance Orig")
newbalanceOrig = st.text_input("New balance Orig")
oldbalanceDest = st.text_input("Old balance Dest")
newbalanceDest = st.text_input("New balance Dest")

type_index = {'CASH_IN': 0, 'CASH_OUT': 1, 'DEBIT': 2, 
            'PAYMENT': 3, 'TRANSFER': 4}

# Define the submit button
submit_button = st.button("Submit")
generate_button = st.button("Generate & Submit")

# When the submit button is clicked, run the machine learning model with the credit card information
if submit_button:   
    df_ = pd.DataFrame([[np.random.choice(100), int(type_index[type]),
            int(amount),
            int(oldbalanceOrig),
            int(newbalanceOrig),
            int(oldbalanceDest),
            int(newbalanceDest), np.random.choice(2)]])#.values

    df_.columns = ['step', 'type','amount', 'oldbalanceOrig'
                'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest', '', '-']
    st.write(df_[['type','amount', 'oldbalanceOrig'
                'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']])

    # Transform the data using the PCA object
    result = makePcaPred(df_)
    if result.item() == 1:
        st.success(f"Its a fraud")
    else:
        st.warning(f"Not Fraud")

# generate random values
if generate_button:   

    df_ = pd.DataFrame([[np.random.choice(100), np.random.choice(5),
            int( np.random.uniform(low=0, high=10000)),
            int( np.random.uniform(low=0, high=10000)),
            int( np.random.uniform(low=0, high=10000)),
            int( np.random.uniform(low=0, high=10000)),
            int( np.random.uniform(low=0, high=10000)), np.random.choice(2)]])#.values

    print(df_)

    df_.columns = ['step', 'type','amount', 'oldbalanceOrig'
                'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest', '','-']
    print(df_.columns)
    print(df_['type'])
    print(df_)
    # print(df_.columns['type','amount', 'oldbalanceOrig'
    #             'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest'])
    st.write(df_[['type','amount', 'oldbalanceOrig'
                'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']])
    result = makePcaPred(df_.values)
    if result.item() == 1:
        st.success(f"Its a fraud")
    else:
        st.warning(f"Not Fraud")

